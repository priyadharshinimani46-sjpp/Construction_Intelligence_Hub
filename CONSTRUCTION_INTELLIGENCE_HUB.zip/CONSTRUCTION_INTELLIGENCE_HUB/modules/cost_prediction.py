import streamlit as st
from utils.ml_models import train_cost_model, predict_cost

def render():
    # Header Section with custom styling
    st.markdown("""
        <div style="text-align: center; padding: 10px 0 20px 0;">
            <h1 style="margin-bottom: 5px;">💰 AI Construction Cost Estimator</h1>
            <p style="color: #8B949E; font-size: 1.05rem; font-weight: 500;">
                Predict total budget requirements powered by trained Machine Learning models
            </p>
        </div>
        <hr style="border: 0; height: 1px; background: linear-gradient(to right, rgba(0, 229, 255, 0), rgba(0, 229, 255, 0.75), rgba(0, 229, 255, 0)); margin-bottom: 30px;">
    """, unsafe_allow_html=True)

    # Input Form Layout inside a modern container card
    st.markdown("<h4 style='color: #00E5FF; margin-bottom: 15px;'>📋 Project Parameters</h4>", unsafe_allow_html=True)
    
    with st.container():
        col1, col2 = st.columns(2, gap="medium")

        with col1:
            area = st.number_input(
                "📐 Total Built-up Area (sq ft)", 
                min_value=100, 
                value=2500, 
                step=100,
                help="Enter total gross floor area across all levels"
            )
            floors = st.number_input(
                "🏢 Number of Floors", 
                min_value=1, 
                value=2, 
                step=1,
                help="Total vertical levels planned"
            )

        with col2:
            workers = st.number_input(
                "👷 Average On-site Workers", 
                min_value=1, 
                value=20, 
                step=1,
                help="Estimated daily workforce presence"
            )
            days = st.number_input(
                "⏱️ Estimated Duration (Days)", 
                min_value=1, 
                value=90, 
                step=5,
                help="Project completion timeline from ground-break to hand-off"
            )

    st.markdown("<br>", unsafe_allow_html=True)

    # Action Button
    if st.button("🚀 Calculate Estimated Cost", type="primary", use_container_width=True):
        with st.spinner("🔄 Training model & computing financial forecast..."):
            model = train_cost_model()
            predicted_cost = predict_cost(model, area, floors, workers, days)

        # Calculate quick contextual insights
        cost_per_sqft = predicted_cost / area if area > 0 else 0
        daily_burn_rate = predicted_cost / days if days > 0 else 0

        st.markdown("<hr style='border: 0; height: 1px; background: #30363D; margin: 30px 0;'>", unsafe_allow_html=True)
        st.markdown("<h3 style='text-align: center; margin-bottom: 25px;'>📊 Financial Projection Summary</h3>", unsafe_allow_html=True)

        # Primary Result Metric Box
        st.markdown(f"""
            <div style="background-color: #161B22; border: 2px solid #00E5FF; border-radius: 12px; padding: 25px; text-align: center; margin-bottom: 25px;">
                <span style="color: #8B949E; text-transform: uppercase; letter-spacing: 1.5px; font-weight: 600; font-size: 0.9rem;">Estimated Total Construction Cost</span>
                <h1 style="color: #00E5FF; font-size: 3rem; margin: 10px 0 0 0; font-weight: 800;">${predicted_cost:,.2f}</h1>
            </div>
        """, unsafe_allow_html=True)

        # Secondary Analytics Metrics
        m_col1, m_col2, m_col3 = st.columns(3)

        with m_col1:
            st.markdown(f"""
                <div style="background-color: #161B22; border: 1px solid #30363D; border-radius: 10px; padding: 15px; text-align: center;">
                    <p style="color: #8B949E; margin: 0; font-size: 0.85rem;">Unit Cost</p>
                    <p style="color: #F0F6FC; font-size: 1.3rem; font-weight: 700; margin: 5px 0 0 0;">${cost_per_sqft:,.2f} <span style="font-size: 0.8rem; font-weight: 400; color: #8B949E;">/ sq ft</span></p>
                </div>
            """, unsafe_allow_html=True)

        with m_col2:
            st.markdown(f"""
                <div style="background-color: #161B22; border: 1px solid #30363D; border-radius: 10px; padding: 15px; text-align: center;">
                    <p style="color: #8B949E; margin: 0; font-size: 0.85rem;">Daily Burn Rate</p>
                    <p style="color: #F0F6FC; font-size: 1.3rem; font-weight: 700; margin: 5px 0 0 0;">${daily_burn_rate:,.2f} <span style="font-size: 0.8rem; font-weight: 400; color: #8B949E;">/ day</span></p>
                </div>
            """, unsafe_allow_html=True)

        with m_col3:
            st.markdown(f"""
                <div style="background-color: #161B22; border: 1px solid #30363D; border-radius: 10px; padding: 15px; text-align: center;">
                    <p style="color: #8B949E; margin: 0; font-size: 0.85rem;">Labor Allocation</p>
                    <p style="color: #F0F6FC; font-size: 1.3rem; font-weight: 700; margin: 5px 0 0 0;">{workers * days:,} <span style="font-size: 0.8rem; font-weight: 400; color: #8B949E;">man-days</span></p>
                </div>
            """, unsafe_allow_html=True)
