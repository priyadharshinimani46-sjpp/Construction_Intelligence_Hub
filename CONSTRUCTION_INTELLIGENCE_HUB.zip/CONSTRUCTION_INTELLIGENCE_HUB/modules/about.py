import streamlit as st

def render():
    # Header Section with custom styling
    st.markdown("""
        <div style="text-align: center; padding: 20px 0 10px 0;">
            <h1 style="margin-bottom: 0px;">ℹ️ About Construction Intelligence Hub</h1>
            <p style="color: #8B949E; font-size: 1.1rem; font-weight: 500;">
                Next-Generation AI & Analytics for Modern Construction Management
            </p>
        </div>
        <hr style="border: 0; height: 1px; background: linear-gradient(to right, rgba(0, 229, 255, 0), rgba(0, 229, 255, 0.75), rgba(0, 229, 255, 0)); margin-bottom: 35px;">
    """, unsafe_allow_html=True)

    # Mission Statement Box
    st.markdown("""
        <div style="background-color: #161B22; border-left: 4px solid #00E5FF; padding: 20px; border-radius: 0 10px 10px 0; margin-bottom: 30px;">
            <p style="margin: 0; font-size: 1.05rem; line-height: 1.6; color: #F0F6FC;">
                <strong>Construction Intelligence Hub</strong> is an end-to-end platform built to streamline the construction project lifecycle. By uniting advanced artificial intelligence, predictive machine learning, and computer vision, it transforms complex site data into actionable, real-time insights.
            </p>
        </div>
    """, unsafe_allow_html=True)

    st.subheader("🛠️ Core Capabilities")

    # Feature Grid
    col1, col2 = st.columns(2)

    with col1:
        st.markdown("""
            <div style="background-color: #161B22; border: 1px solid #30363D; border-radius: 12px; padding: 20px; height: 100%;">
                <h4 style="color: #00E5FF; margin-top: 0;">🤖 LLM Intelligence</h4>
                <p style="color: #8B949E; font-size: 0.95rem;">Powered by <b>Ollama</b></p>
                <p style="color: #C9D1D9; font-size: 0.95rem; margin-bottom: 0;">
                    Instant sitewide context querying, automated compliance checks, and intelligent building code navigation.
                </p>
            </div>
        """, unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        st.markdown("""
            <div style="background-color: #161B22; border: 1px solid #30363D; border-radius: 12px; padding: 20px; height: 100%;">
                <h4 style="color: #00E5FF; margin-top: 0;">👁️ Computer Vision</h4>
                <p style="color: #8B949E; font-size: 0.95rem;">Automated Site Surveillance</p>
                <p style="color: #C9D1D9; font-size: 0.95rem; margin-bottom: 0;">
                    Real-time monitoring for Personal Protective Equipment (PPE) compliance and active site hazard detection.
                </p>
            </div>
        """, unsafe_allow_html=True)

    with col2:
        st.markdown("""
            <div style="background-color: #161B22; border: 1px solid #30363D; border-radius: 12px; padding: 20px; height: 100%;">
                <h4 style="color: #00E5FF; margin-top: 0;">📈 Machine Learning</h4>
                <p style="color: #8B949E; font-size: 0.95rem;">Predictive Risk Modeling</p>
                <p style="color: #C9D1D9; font-size: 0.95rem; margin-bottom: 0;">
                    Accurate forecasting for cost overruns and potential schedule delays before they impact your timeline.
                </p>
            </div>
        """, unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        st.markdown("""
            <div style="background-color: #161B22; border: 1px solid #30363D; border-radius: 12px; padding: 20px; height: 100%;">
                <h4 style="color: #00E5FF; margin-top: 0;">📊 Real-Time Analytics</h4>
                <p style="color: #8B949E; font-size: 0.95rem;">Performance Dashboard</p>
                <p style="color: #C9D1D9; font-size: 0.95rem; margin-bottom: 0;">
                    Unified telemetry tracking progress metrics, budget utilization, and critical project health indicators.
                </p>
            </div>
        """, unsafe_allow_html=True)
