import streamlit as st

def render():
    # Styled Header Section
    st.markdown("""
        <div style="text-align: center; padding: 10px 0 20px 0;">
            <h1 style="margin-bottom: 5px;">🦺 Site Safety & Compliance</h1>
            <p style="color: #8B949E; font-size: 1.05rem; font-weight: 500;">
                Log Site Incidents, Track Near-Misses, and Maintain OSHA Audit Compliance
            </p>
        </div>
        <hr style="border: 0; height: 1px; background: linear-gradient(to right, rgba(0, 229, 255, 0), rgba(0, 229, 255, 0.75), rgba(0, 229, 255, 0)); margin-bottom: 30px;">
    """, unsafe_allow_html=True)

    # Incident Logging Form Layout
    st.markdown("<h4 style='color: #00E5FF; margin-bottom: 15px;'>📝 Log Safety Incident / Observation</h4>", unsafe_allow_html=True)

    col1, col2 = st.columns([1, 1], gap="large")

    with col1:
        incident_type = st.selectbox(
            "⚠️ Observation Category", 
            [
                "Near Miss", 
                "Property Damage", 
                "Hazard Identification", 
                "Minor Injury"
            ],
            help="Select the classification that best describes the event."
        )

        # Dynamic Severity Badge based on Selection
        severity_colors = {
            "Near Miss": ("#FFAB00", "MODERATE ATTENTION", "Potential safety event that was narrowly avoided."),
            "Property Damage": ("#FF5252", "HIGH SEVERITY", "Physical site asset or equipment destruction reported."),
            "Hazard Identification": ("#00E5FF", "PREVENTATIVE OBS", "Proactive reporting of unsanitary or risky conditions."),
            "Minor Injury": ("#FF5252", "HIGH SEVERITY", "Personnel required first-aid or medical assistance.")
        }

        color, level, label_desc = severity_colors.get(incident_type, ("#00E5FF", "INFO", ""))

        st.markdown(f"""
            <div style="background-color: #161B22; border-left: 4px solid {color}; padding: 12px 16px; border-radius: 0 8px 8px 0; margin-top: 10px;">
                <span style="color: {color}; font-size: 0.75rem; font-weight: 700; letter-spacing: 1px;">{level}</span>
                <p style="color: #C9D1D9; font-size: 0.88rem; margin: 4px 0 0 0;">{label_desc}</p>
            </div>
        """, unsafe_allow_html=True)

    with col2:
        desc = st.text_area(
            "📄 Incident Description",
            placeholder="Describe what occurred, exact zone/location on site, personnel involved, and immediate actions taken...",
            height=130
        )

    st.markdown("<br>", unsafe_allow_html=True)

    # Submit Action & Success State
    if st.button("🚨 Submit Incident Report", type="primary", use_container_width=True):
        if not desc.strip():
            st.warning("⚠️ Please provide a brief description before submitting the incident report.")
        else:
            st.markdown("<hr style='border: 0; height: 1px; background: #30363D; margin: 25px 0;'>", unsafe_allow_html=True)
            
            st.markdown("""
                <div style="background-color: rgba(0, 230, 118, 0.1); border: 1px solid #00E676; border-radius: 10px; padding: 20px; text-align: center;">
                    <span style="color: #00E676; font-size: 1.5rem;">✅</span>
                    <h3 style="color: #00E676; margin: 5px 0;">Safety Incident Logged Successfully</h3>
                    <p style="color: #F0F6FC; margin: 0; font-size: 0.95rem;">
                        The report has been registered in the compliance database and dispatched to the Safety Officer.
                    </p>
                </div>
            """, unsafe_allow_html=True)

            # Logged Summary Card
            st.markdown(f"""
                <div style="background-color: #161B22; border: 1px solid #30363D; border-radius: 8px; padding: 15px; margin-top: 15px;">
                    <p style="color: #8B949E; margin: 0 0 5px 0; font-size: 0.8rem; font-weight: 600;">LOG ENTRY SUMMARY</p>
                    <p style="color: #F0F6FC; margin: 0; font-weight: 600;">Category: <span style="color: {color};">{incident_type}</span></p>
                    <p style="color: #C9D1D9; margin: 5px 0 0 0; font-size: 0.9rem;">"{desc}"</p>
                </div>
            """, unsafe_allow_html=True)
