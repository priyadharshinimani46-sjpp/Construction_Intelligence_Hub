import streamlit as st
from PIL import Image

def render():
    # Styled Header Section
    st.markdown("""
        <div style="text-align: center; padding: 10px 0 20px 0;">
            <h1 style="margin-bottom: 5px;">👁️ Computer Vision Site Inspection</h1>
            <p style="color: #8B949E; font-size: 1.05rem; font-weight: 500;">
                Automated PPE Compliance & Real-Time Hazard Detection
            </p>
        </div>
        <hr style="border: 0; height: 1px; background: linear-gradient(to right, rgba(0, 229, 255, 0), rgba(0, 229, 255, 0.75), rgba(0, 229, 255, 0)); margin-bottom: 30px;">
    """, unsafe_allow_html=True)

    # File Uploader Container
    st.markdown("<h4 style='color: #00E5FF; margin-bottom: 10px;'>📸 Image Upload & Analysis</h4>", unsafe_allow_html=True)
    uploaded_file = st.file_uploader("Upload Site Image (JPG, JPEG, PNG)", type=["jpg", "jpeg", "png"])

    if uploaded_file is not None:
        image = Image.open(uploaded_file)
        
        # Two-column layout: Image on the left, Results on the right
        col1, col2 = st.columns([1, 1], gap="large")

        with col1:
            st.markdown("<p style='color: #8B949E; font-weight: 600; font-size: 0.9rem;'>INSPECTED SITE FRAME</p>", unsafe_allow_html=True)
            st.image(image, caption="Uploaded Construction Site Image", use_container_width=True)

        with col2:
            st.markdown("<p style='color: #8B949E; font-weight: 600; font-size: 0.9rem;'>AUTOMATED ANALYSIS REPORT</p>", unsafe_allow_html=True)
            
            with st.spinner("🔍 Running neural vision model..."):
                # Overall Status Alert Badge
                st.markdown("""
                    <div style="background-color: rgba(255, 171, 0, 0.1); border: 1px solid #FFAB00; border-radius: 8px; padding: 12px 16px; margin-bottom: 20px;">
                        <span style="color: #FFAB00; font-weight: 700; font-size: 1rem;">⚠️ Inspection Warning</span>
                        <p style="color: #F0F6FC; margin: 4px 0 0 0; font-size: 0.9rem;">Site is mostly compliant, but 1 active hazard requires immediate attention.</p>
                    </div>
                """, unsafe_allow_html=True)

                # Compliance Metrics Grid
                m1, m2 = st.columns(2)
                with m1:
                    st.markdown("""
                        <div style="background-color: #161B22; border: 1px solid #30363D; border-radius: 10px; padding: 15px; text-align: center;">
                            <span style="font-size: 1.5rem;">🪖</span>
                            <p style="color: #8B949E; margin: 5px 0 0 0; font-size: 0.8rem;">Hardhat Compliance</p>
                            <h2 style="color: #00E676; font-size: 1.8rem; margin: 0; font-weight: 800;">95%</h2>
                        </div>
                    """, unsafe_allow_html=True)

                with m2:
                    st.markdown("""
                        <div style="background-color: #161B22; border: 1px solid #30363D; border-radius: 10px; padding: 15px; text-align: center;">
                            <span style="font-size: 1.5rem;">🦺</span>
                            <p style="color: #8B949E; margin: 5px 0 0 0; font-size: 0.8rem;">Safety Vest Compliance</p>
                            <h2 style="color: #00E676; font-size: 1.8rem; margin: 0; font-weight: 800;">100%</h2>
                        </div>
                    """, unsafe_allow_html=True)

                st.markdown("<br>", unsafe_allow_html=True)

                # Detailed Inspection Findings
                st.markdown("<h5 style='color: #F0F6FC; margin-bottom: 10px;'>Detailed Audit Breakdown</h5>", unsafe_allow_html=True)

                st.markdown("""
                    <div style="background-color: #161B22; border-left: 4px solid #00E676; padding: 12px 15px; border-radius: 0 8px 8px 0; margin-bottom: 10px;">
                        <span style="color: #00E676; font-weight: 700;">✅ Hardhat Verification</span>
                        <p style="color: #C9D1D9; font-size: 0.88rem; margin: 2px 0 0 0;">19 of 20 detected personnel are wearing required head protection.</p>
                    </div>

                    <div style="background-color: #161B22; border-left: 4px solid #00E676; padding: 12px 15px; border-radius: 0 8px 8px 0; margin-bottom: 10px;">
                        <span style="color: #00E676; font-weight: 700;">✅ High-Visibility Gear</span>
                        <p style="color: #C9D1D9; font-size: 0.88rem; margin: 2px 0 0 0;">All detected personnel are equipped with compliant high-vis jackets/vests.</p>
                    </div>

                    <div style="background-color: #161B22; border-left: 4px solid #FFAB00; padding: 12px 15px; border-radius: 0 8px 8px 0; margin-bottom: 10px;">
                        <span style="color: #FFAB00; font-weight: 700;">⚠️ Hazard Warning (Zone B)</span>
                        <p style="color: #C9D1D9; font-size: 0.88rem; margin: 2px 0 0 0;">Unsecured scaffolding and missing guardrail noticed near Zone B framework.</p>
                    </div>
                """, unsafe_allow_html=True)
