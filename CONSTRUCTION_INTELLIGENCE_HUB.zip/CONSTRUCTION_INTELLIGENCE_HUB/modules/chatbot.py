import streamlit as st
import requests

OLLAMA_API_URLS = [
    "http://127.0.0.1:11434/api/generate",
    "http://localhost:11434/api/generate",
]
OLLAMA_MODEL = "llama3.2"
OLLAMA_ROOT_URLS = [
    "http://127.0.0.1:11434",
    "http://localhost:11434",
]

def check_ollama_connection():
    for root_url in OLLAMA_ROOT_URLS:
        try:
            response = requests.get(root_url, timeout=2)
            if response.status_code == 200:
                return True, root_url
        except requests.RequestException:
            continue
    return False, OLLAMA_ROOT_URLS[0]


def request_ollama(payload):
    last_exception = None
    for url in OLLAMA_API_URLS:
        try:
            return requests.post(url, json=payload, timeout=(5, 60)), url
        except requests.RequestException as exc:
            last_exception = exc
            continue
    raise last_exception or RuntimeError("Unable to reach Ollama on any configured host.")

def render():
    # Styled Header Section
    connected, checked_host = check_ollama_connection()
    status_color = "#3dff99" if connected else "#ff5f5f"
    status_text = "Connected" if connected else "Offline"

    st.markdown(f"""
        <div style="text-align: center; padding: 10px 0 20px 0;">
            <h1 style="margin-bottom: 5px;">💬 Construction AI Assistant</h1>
            <p style="color: #8B949E; font-size: 1.05rem; font-weight: 500;">
                Powered by Local Ollama (<code style="color: #00E5FF;">{OLLAMA_MODEL}</code>) • Real-time Engineering Intelligence
            </p>
        </div>
        <hr style="border: 0; height: 1px; background: linear-gradient(to right, rgba(0, 229, 255, 0), rgba(0, 229, 255, 0.75), rgba(0, 229, 255, 0)); margin-bottom: 25px;">
    """, unsafe_allow_html=True)

    st.markdown(f"""
        <div style='background-color: #0D1117; border: 1px solid #30363D; border-radius: 10px; padding: 14px; margin-bottom: 22px;'>
            <div style='display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 12px;'>
                <div style='min-width: 270px;'>
                    <p style='margin: 0; color: #8B949E;'>This chat uses the local Ollama HTTP API at <code>{checked_host}/api/generate</code>.</p>
                    <p style='margin: 6px 0 0 0; color: #8B949E; font-size: 0.9rem;'>Run <code>ollama run llama3.2</code> in a separate terminal if the assistant cannot connect.</p>
                    <p style='margin: 8px 0 0 0; color: #8B949E; font-size: 0.85rem;'>Responses may take up to 20 seconds depending on local model latency.</p>
                </div>
                <div style='background: {status_color}; border-radius: 999px; padding: 8px 14px; color: #0B1120; font-weight: 700;'>
                    {status_text}
                </div>
            </div>
        </div>
    """, unsafe_allow_html=True)

    # Sidebar Controls & Information
    with st.sidebar:
        st.markdown("### ⚙️ Engine Status")
        st.markdown(f"""
            <div style="background-color: #161B22; border: 1px solid #30363D; border-radius: 8px; padding: 12px; margin-bottom: 15px;">
                <span style="color: #00E676;">● Active Engine:</span> <b>Ollama</b><br>
                <span style="color: #8B949E; font-size: 0.85rem;">Model: <code>{OLLAMA_MODEL}</code></span>
            </div>
        """, unsafe_allow_html=True)
        
        if st.button("🗑️ Clear Chat History", width="stretch"):
            st.session_state.messages = []
            st.rerun()

    # Initialize chat history
    if "messages" not in st.session_state:
        st.session_state.messages = [
            {
                "role": "assistant", 
                "content": "Hello! I am your Construction Intelligence Assistant. Ask me about **OSHA safety standards**, **building code compliance**, **concrete curing schedules**, or **site risk management**."
            }
        ]

    # Quick Suggestion Chips (Shows only when chat is fresh)
    if len(st.session_state.messages) <= 1:
        st.markdown("<p style='color: #8B949E; font-weight: 600; font-size: 0.9rem;'>QUICK TOPICS</p>", unsafe_allow_html=True)
        col1, col2, col3 = st.columns(3)
        
        prompt_to_submit = None
        with col1:
            if st.button("🦺 OSHA PPE Requirements", width="stretch"):
                prompt_to_submit = "What are the essential OSHA PPE compliance requirements for high-rise excavation sites?"
        with col2:
            if st.button("🧱 Concrete Curing Times", width="stretch"):
                prompt_to_submit = "Summarize ideal concrete curing times and temperature thresholds for structural slabs."
        with col3:
            if st.button("📋 Delay Mitigation", width="stretch"):
                prompt_to_submit = "Give me a checklist for mitigating weather-related schedule delays on site."
    else:
        prompt_to_submit = None

    response_style = st.selectbox(
        "Answer speed",
        ["Fastest", "Fast", "Balanced", "Detailed"],
        index=0,
        help="Fastest answers are the shortest and return fastest; Detailed answers may take longer."
    )

    style_settings = {
        "Fastest": {
            "max_tokens": 40,
            "temperature": 0.0,
            "prompt_suffix": "Answer in one short sentence.",
        },
        "Fast": {
            "max_tokens": 80,
            "temperature": 0.0,
            "prompt_suffix": "Keep the answer extremely short and direct, within 25 words.",
        },
        "Balanced": {
            "max_tokens": 160,
            "temperature": 0.1,
            "prompt_suffix": "Keep the answer concise and clear.",
        },
        "Detailed": {
            "max_tokens": 260,
            "temperature": 0.2,
            "prompt_suffix": "Provide a helpful, detailed answer without unnecessary explanation.",
        },
    }
    selected_params = style_settings.get(response_style, style_settings["Fastest"])

    # Display chat history with clean icons
    for message in st.session_state.messages:
        avatar = "👷" if message["role"] == "user" else "🤖"
        with st.chat_message(message["role"], avatar=avatar):
            st.markdown(message["content"])

    # User Input Handling (either from text bar or quick button)
    user_input = st.chat_input("Ask anything about construction management, safety, or codes...")
    
    if prompt_to_submit or user_input:
        prompt = prompt_to_submit if prompt_to_submit else user_input
        
        # Save & display user message
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user", avatar="👷"):
            st.markdown(prompt)

        # Process response from Ollama
        with st.chat_message("assistant", avatar="🤖"):
            message_placeholder = st.empty()
            full_response = ""

            payload = {
                "model": OLLAMA_MODEL,
                "prompt": (
                    f"You are a construction engineering assistant. {selected_params['prompt_suffix']}\n"
                    f"User Query: {prompt}"
                ),
                "max_tokens": selected_params["max_tokens"],
                "temperature": selected_params["temperature"],
                "stream": False
            }

            try:
                with st.spinner("Generating answer from Ollama. This may take up to 20 seconds..."):
                    response, used_url = request_ollama(payload)

                if response.status_code == 200:
                    result = response.json()
                    full_response = (
                        result.get("response")
                        or result.get("text")
                        or result.get("output")
                        or "No response received from Ollama."
                    )
                    message_placeholder.markdown(full_response)
                else:
                    try:
                        error_result = response.json()
                        full_response = error_result.get("error", f"⚠️ **Ollama Service Error** (Status Code: `{response.status_code}`)")
                    except Exception:
                        full_response = f"⚠️ **Ollama Service Error** (Status Code: `{response.status_code}`)"
                    message_placeholder.error(full_response)

            except requests.exceptions.ConnectionError:
                full_response = (
                    "❌ **Connection Failed**: Could not connect to the local Ollama server. "
                    "Make sure `ollama run llama3.2` is running in a separate terminal."
                )
                message_placeholder.error(full_response)
            except requests.Timeout:
                full_response = (
                    "⏳ **Timeout**: Connection timed out while connecting to Ollama server. "
                    "Try restarting Ollama or verify the server is listening on port `11434`."
                )
                message_placeholder.warning(full_response)
            except Exception as e:
                full_response = f"⚠️ **Unexpected Error**: `{str(e)}`"
                message_placeholder.error(full_response)

        # Save assistant message to history
        st.session_state.messages.append({"role": "assistant", "content": full_response})
