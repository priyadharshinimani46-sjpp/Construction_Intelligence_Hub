import streamlit as st

def render():
    # Styled Header Section
    st.markdown("""
        <div style="text-align: center; padding: 10px 0 20px 0;">
            <h1 style="margin-bottom: 5px;">⏳ Schedule & Delay Risk Prediction</h1>
            <p style="color: #8B949E; font-size: 1.05rem; font-weight: 500;">
                Predict potential timeline bottlenecks & quantify site schedule vulnerability
            </p>
        </div>
        <hr style="border: 0; height: 1px; background: linear-gradient(to right, rgba(0, 229, 255, 0), rgba(0, 229, 255, 0.75), rgba(0, 229, 255, 0)); margin-bottom: 30px;">
    """, unsafe_allow_html=True)

    # Project Conditions Input Form
    st.markdown("<h4 style='color: #00E5FF; margin-bottom: 15px;'>⚙️ Project Conditions Assessment</h4>", unsafe_allow_html=True)
    
    col1, col2 = st.columns(2, gap="large")

    with col1:
        weather_risk = st.selectbox(
            "🌧️ Expected Weather Disruptions", 
            ["Low", "Medium", "High"],
            help="Forecasted impact of adverse local weather conditions"
        )
        supply_chain = st.selectbox(
            "🚚 Supply Chain Reliability", 
            ["High", "Moderate", "Low"],
            help="Availability and delivery timeline stability of critical materials"
        )

    with col2:
        labor_avail = st.slider(
            "👷 Labor Workforce Capacity (%)", 
            min_value=50, 
            max_value=100, 
            value=85,
            step=5,
            help="Current vs planned on-site subcontractor staffing percentage"
        )

    st.markdown("<br>", unsafe_allow_html=True)

    # Risk Assessment Trigger
    if st.button("🚨 Assess Delay Risk", type="primary", use_container_width=True):
        # Calculate Risk Score (Exact logic retained)
        risk_score = 0
        if weather_risk == "High": 
            risk_score += 35
        elif weather_risk == "Medium": 
            risk_score += 15
        
        if supply_chain == "Low": 
            risk_score += 40
        elif supply_chain == "Moderate": 
            risk_score += 20
        
        if labor_avail < 70: 
            risk_score += 25

        st.markdown("<hr style='border: 0; height: 1px; background: #30363D; margin: 30px 0;'>", unsafe_allow_html=True)
        st.markdown("<h3 style='text-align: center; margin-bottom: 20px;'>📊 Risk Assessment Summary</h3>", unsafe_allow_html=True)

        # Dynamic Risk Gauge & Status Rendering
        if risk_score > 50:
            status_color = "#FF5252"
            status_bg = "rgba(255, 82, 82, 0.1)"
            status_title = "HIGH DELAY RISK"
            status_desc = "High probability of critical path schedule slippage. Immediate intervention recommended."
            action_tips = [
                "Negotiate expedited shipping options for delayed materials.",
                "Implement overtime shifts or reallocate workforce to critical path tasks.",
                "Review buffer allocations in project schedule baseline."
            ]
        elif risk_score > 25:
            status_color = "#FFAB00"
            status_bg = "rgba(255, 171, 0, 0.1)"
            status_title = "MODERATE DELAY RISK"
            status_desc = "Minor schedule friction expected. Active monitoring required."
            action_tips = [
                "Track material lead times weekly with key suppliers.",
                "Prepare weather contingency measures for outdoor activities."
            ]
        else:
            status_color = "#00E676"
            status_bg = "rgba(0, 230, 118, 0.1)"
            status_title = "LOW DELAY RISK"
            status_desc = "Project timeline is healthy and well-optimized. Operations are on target."
            action_tips = [
                "Maintain current labor deployment and supply chain pacing."
            ]

        # Primary Risk Metric Box
        st.markdown(f"""
            <div style="background-color: {status_bg}; border: 2px solid {status_color}; border-radius: 12px; padding: 25px; text-align: center; margin-bottom: 25px;">
                <span style="color: {status_color}; text-transform: uppercase; letter-spacing: 1.5px; font-weight: 700; font-size: 0.9rem;">
                    {status_title}
                </span>
                <h1 style="color: {status_color}; font-size: 3.2rem; margin: 5px 0; font-weight: 800;">
                    {risk_score}%
                </h1>
                <p style="color: #F0F6FC; font-size: 1rem; margin: 0; font-weight: 500;">
                    {status_desc}
                </p>
            </div>
        """, unsafe_allow_html=True)

        # Actionable Mitigation Guidance
        st.markdown("<h5 style='color: #F0F6FC; margin-bottom: 12px;'>💡 Recommended Action Plan</h5>", unsafe_allow_html=True)
        for tip in action_tips:
            st.markdown(f"""
                <div style="background-color: #161B22; border-left: 4px solid {status_color}; padding: 12px 16px; border-radius: 0 8px 8px 0; margin-bottom: 10px;">
                    <p style="color: #C9D1D9; font-size: 0.9rem; margin: 0;">• {tip}</p>
                </div>
            """, unsafe_allow_html=True)
