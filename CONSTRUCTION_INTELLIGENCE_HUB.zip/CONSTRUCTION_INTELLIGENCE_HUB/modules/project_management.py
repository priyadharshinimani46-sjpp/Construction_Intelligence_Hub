import streamlit as st
import pandas as pd

def render():
    # Styled Header Section
    st.markdown("""
        <div style="text-align: center; padding: 10px 0 20px 0;">
            <h1 style="margin-bottom: 5px;">📋 Project Task Management</h1>
            <p style="color: #8B949E; font-size: 1.05rem; font-weight: 500;">
                Track, Filter, and Manage Site Operations & Work Assignments
            </p>
        </div>
        <hr style="border: 0; height: 1px; background: linear-gradient(to right, rgba(0, 229, 255, 0), rgba(0, 229, 255, 0.75), rgba(0, 229, 255, 0)); margin-bottom: 30px;">
    """, unsafe_allow_html=True)

    # Base Data
    tasks_data = [
        {"Task": "Foundation Concrete Pouring", "Status": "Completed", "Assignee": "John Doe", "Priority": "High"},
        {"Task": "Steel Framing Phase 1", "Status": "In Progress", "Assignee": "Sarah Smith", "Priority": "Critical"},
        {"Task": "Electrical Wiring - Floor 2", "Status": "Pending", "Assignee": "Mike Johnson", "Priority": "Medium"},
        {"Task": "HVAC Ductwork Installation", "Status": "In Progress", "Assignee": "Alex Rivera", "Priority": "High"},
        {"Task": "Site Safety Inspection Audit", "Status": "Completed", "Assignee": "Sarah Smith", "Priority": "Medium"},
    ]
    
    df = pd.DataFrame(tasks_data)

    # Summary KPI Bar
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.markdown(f"""
            <div style="background-color: #161B22; border: 1px solid #30363D; border-radius: 10px; padding: 12px; text-align: center;">
                <p style="color: #8B949E; margin: 0; font-size: 0.8rem; font-weight: 600;">TOTAL TASKS</p>
                <h3 style="color: #F0F6FC; margin: 4px 0 0 0; font-size: 1.4rem;">{len(df)}</h3>
            </div>
        """, unsafe_allow_html=True)
    with c2:
        completed_cnt = len(df[df["Status"] == "Completed"])
        st.markdown(f"""
            <div style="background-color: #161B22; border: 1px solid #30363D; border-radius: 10px; padding: 12px; text-align: center;">
                <p style="color: #8B949E; margin: 0; font-size: 0.8rem; font-weight: 600;">COMPLETED</p>
                <h3 style="color: #00E676; margin: 4px 0 0 0; font-size: 1.4rem;">{completed_cnt}</h3>
            </div>
        """, unsafe_allow_html=True)
    with c3:
        in_prog_cnt = len(df[df["Status"] == "In Progress"])
        st.markdown(f"""
            <div style="background-color: #161B22; border: 1px solid #30363D; border-radius: 10px; padding: 12px; text-align: center;">
                <p style="color: #8B949E; margin: 0; font-size: 0.8rem; font-weight: 600;">IN PROGRESS</p>
                <h3 style="color: #00E5FF; margin: 4px 0 0 0; font-size: 1.4rem;">{in_prog_cnt}</h3>
            </div>
        """, unsafe_allow_html=True)
    with c4:
        pending_cnt = len(df[df["Status"] == "Pending"])
        st.markdown(f"""
            <div style="background-color: #161B22; border: 1px solid #30363D; border-radius: 10px; padding: 12px; text-align: center;">
                <p style="color: #8B949E; margin: 0; font-size: 0.8rem; font-weight: 600;">PENDING</p>
                <h3 style="color: #FFAB00; margin: 4px 0 0 0; font-size: 1.4rem;">{pending_cnt}</h3>
            </div>
        """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # Interactive Filters Row
    f_col1, f_col2 = st.columns([1, 1])
    with f_col1:
        status_filter = st.multiselect(
            "🔍 Filter by Status", 
            options=["Completed", "In Progress", "Pending"], 
            default=["Completed", "In Progress", "Pending"]
        )
    with f_col2:
        priority_filter = st.multiselect(
            "🚨 Filter by Priority", 
            options=["Critical", "High", "Medium", "Low"], 
            default=["Critical", "High", "Medium", "Low"]
        )

    # Apply Filters
    filtered_df = df[
        (df["Status"].isin(status_filter)) & 
        (df["Priority"].isin(priority_filter))
    ]

    st.markdown("<h4 style='color: #00E5FF; margin: 15px 0 10px 0;'>📌 Active Work Schedule</h4>", unsafe_allow_html=True)

    # Styled Streamlit Dataframe with Tag Badges
    st.dataframe(
        filtered_df,
        column_config={
            "Task": st.column_config.TextColumn(
                "Task Description",
                width="large"
            ),
            "Status": st.column_config.SelectboxColumn(
                "Current Status",
                options=["Completed", "In Progress", "Pending"],
                width="medium",
                required=True
            ),
            "Assignee": st.column_config.TextColumn(
                "Assigned Engineer",
                width="medium"
            ),
            "Priority": st.column_config.SelectboxColumn(
                "Priority Level",
                options=["Critical", "High", "Medium", "Low"],
                width="medium",
                required=True
            ),
        },
        use_container_width=True,
        hide_index=True
    )
