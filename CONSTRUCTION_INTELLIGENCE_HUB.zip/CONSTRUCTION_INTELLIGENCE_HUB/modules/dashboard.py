import streamlit as st
import plotly.express as px
from utils.data_gen import get_sample_project_data

def render():
    st.markdown("""
        <div style="text-align: center; padding: 10px 0 20px 0;">
            <h1 style="margin-bottom: 5px;">📊 Project Executive Dashboard</h1>
            <p style="color: #8B949E; font-size: 1.05rem; font-weight: 500;">
                High-Level Overview of Project Financials, Timeline Health & Safety Telemetry
            </p>
        </div>
        <hr style="border: 0; height: 1px; background: linear-gradient(to right, rgba(0, 229, 255, 0), rgba(0, 229, 255, 0.75), rgba(0, 229, 255, 0)); margin-bottom: 30px;">
    """, unsafe_allow_html=True)

    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.markdown("""
            <div style="background-color: #161B22; border: 1px solid #30363D; border-radius: 10px; padding: 16px; text-align: center;">
                <p style="color: #8B949E; margin: 0; font-size: 0.85rem; font-weight: 600;">TOTAL BUDGET</p>
                <h3 style="color: #F0F6FC; margin: 6px 0 2px 0; font-size: 1.6rem; font-weight: 800;">$10.0M</h3>
                <span style="color: #00E676; font-size: 0.8rem; font-weight: 600;">▲ +5% vs initial</span>
            </div>
        """, unsafe_allow_html=True)

    with col2:
        st.markdown("""
            <div style="background-color: #161B22; border: 1px solid #30363D; border-radius: 10px; padding: 16px; text-align: center;">
                <p style="color: #8B949E; margin: 0; font-size: 0.85rem; font-weight: 600;">SPENT TO DATE</p>
                <h3 style="color: #00E5FF; margin: 6px 0 2px 0; font-size: 1.6rem; font-weight: 800;">$4.25M</h3>
                <span style="color: #8B949E; font-size: 0.8rem; font-weight: 600;">42.5% Utilized</span>
            </div>
        """, unsafe_allow_html=True)

    with col3:
        st.markdown("""
            <div style="background-color: #161B22; border: 1px solid #30363D; border-radius: 10px; padding: 16px; text-align: center;">
                <p style="color: #8B949E; margin: 0; font-size: 0.85rem; font-weight: 600;">SCHEDULE VARIANCE</p>
                <h3 style="color: #FF5252; margin: 6px 0 2px 0; font-size: 1.6rem; font-weight: 800;">-4 Days</h3>
                <span style="color: #FF5252; font-size: 0.8rem; font-weight: 600;">▼ Behind Schedule</span>
            </div>
        """, unsafe_allow_html=True)

    with col4:
        st.markdown("""
            <div style="background-color: #161B22; border: 1px solid #30363D; border-radius: 10px; padding: 16px; text-align: center;">
                <p style="color: #8B949E; margin: 0; font-size: 0.85rem; font-weight: 600;">SAFETY SCORE</p>
                <h3 style="color: #00E676; margin: 6px 0 2px 0; font-size: 1.6rem; font-weight: 800;">98%</h3>
                <span style="color: #00E676; font-size: 0.8rem; font-weight: 600;">▲ +2% Incident-free</span>
            </div>
        """, unsafe_allow_html=True)

    st.markdown("<hr style='border: 0; height: 1px; background: #30363D; margin: 30px 0;'>", unsafe_allow_html=True)

    df = get_sample_project_data()
    col_a, col_b = st.columns(2, gap="large")

    chart_theme = dict(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#8B949E", family="sans serif"),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1, title=None),
        margin=dict(l=10, r=10, t=30, b=10),
        xaxis=dict(showgrid=False, zeroline=False),
        yaxis=dict(showgrid=True, gridcolor="#21262D", zeroline=False)
    )

    with col_a:
        st.markdown("<h4 style='color: #F0F6FC; margin-bottom: 15px;'>📈 Budget vs Actual Spend ($)</h4>", unsafe_allow_html=True)
        fig_cost = px.line(df, x="Month", y=["Planned_Budget", "Actual_Cost"], markers=True, color_discrete_sequence=["#8B949E", "#00E5FF"])
        fig_cost.update_traces(line=dict(width=3), marker=dict(size=8))
        fig_cost.update_layout(**chart_theme)
        st.plotly_chart(fig_cost, use_container_width=True)

    with col_b:
        st.markdown("<h4 style='color: #F0F6FC; margin-bottom: 15px;'>📊 Progress Tracking (%)</h4>", unsafe_allow_html=True)
        fig_prog = px.bar(df, x="Month", y=["Planned_Progress", "Actual_Progress"], barmode="group", color_discrete_sequence=["#30363D", "#FF2E93"])
        # Removed marker_corner_radius to prevent Plotly ValueError
        fig_prog.update_layout(**chart_theme)
        st.plotly_chart(fig_prog, use_container_width=True)
