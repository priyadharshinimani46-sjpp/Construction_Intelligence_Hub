import streamlit as st

def apply_custom_css():
    st.markdown(
        """
        <style>
        /* Import Modern Typography */
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

        :root {
            color-scheme: dark;
        }

        /* Base App Canvas & Modern Background */
        .stApp {
            background: 
                radial-gradient(circle at 15% 15%, rgba(0, 229, 255, 0.12), transparent 30%),
                radial-gradient(circle at 85% 85%, rgba(124, 58, 237, 0.12), transparent 30%),
                linear-gradient(180deg, #090D16 0%, #0D111A 100%);
            color: #E2E8F0;
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
        }

        /* Glassmorphic Sidebar Styling */
        [data-testid="stSidebar"] {
            background: rgba(13, 17, 23, 0.85) !important;
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border-right: 1px solid rgba(255, 255, 255, 0.08) !important;
        }

        /* Typography & Headings Styling */
        h1, h2, h3, h4, h5, h6, .stMarkdown h1, .stMarkdown h2, .stMarkdown h3 {
            color: #F8FAFC !important;
            font-family: 'Plus Jakarta Sans', sans-serif !important;
            font-weight: 700 !important;
            letter-spacing: -0.02em !important;
        }

        /* Modern High-Glow Gradient Buttons */
        .stButton > button {
            background: linear-gradient(135deg, #00E5FF 0%, #0088FF 50%, #7C3AED 100%) !important;
            color: #FFFFFF !important;
            font-weight: 600 !important;
            border-radius: 12px !important;
            padding: 0.75rem 1.5rem !important;
            border: none !important;
            box-shadow: 0 4px 20px rgba(0, 229, 255, 0.25) !important;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
        }

        .stButton > button:hover {
            opacity: 0.95 !important;
            transform: translateY(-2px) scale(1.01) !important;
            box-shadow: 0 8px 30px rgba(0, 229, 255, 0.45) !important;
        }

        .stButton > button:active {
            transform: translateY(0px) scale(0.99) !important;
        }

        /* Form Controls: Text Inputs, Text Areas, Select Boxes */
        .stTextInput > div > div > input,
        .stTextArea > div > div > textarea,
        .stSelectbox > div > div > div {
            background: #161B22 !important;
            color: #F0F6FC !important;
            border: 1px solid #30363D !important;
            border-radius: 10px !important;
            padding: 0.65rem 0.85rem !important;
            transition: border-color 0.2s ease, box-shadow 0.2s ease !important;
        }

        .stTextInput > div > div > input:focus,
        .stTextArea > div > div > textarea:focus {
            border-color: #00E5FF !important;
            box-shadow: 0 0 0 3px rgba(0, 229, 255, 0.2) !important;
        }

        /* Alert Banners Styling */
        .stAlert {
            border-radius: 14px !important;
            backdrop-filter: blur(8px) !important;
            border: 1px solid rgba(255, 255, 255, 0.1) !important;
        }

        /* Custom Modern Scrollbars */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        ::-webkit-scrollbar-track {
            background: #0D111A;
        }
        ::-webkit-scrollbar-thumb {
            background: #21262D;
            border-radius: 4px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #30363D;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )
